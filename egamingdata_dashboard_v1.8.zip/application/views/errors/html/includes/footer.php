
  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      Made with <i class="fa fa-heart" style="color: red;"></i> for Developers
      &nbsp; &nbsp; &nbsp; &nbsp; 
      <b>Version</b> 1.0
    </div>
    <strong>Copyright &copy; <?php echo date('Y') ?>. </strong> All rights
    reserved.
  </footer>

</div>
<!-- ./wrapper -->

<!-- date-range-picker -->
<script src="<?php echo config_item('base_url').'/assets/' ?>plugins/moment/min/moment.min.js"></script>

<!-- AdminLTE App -->
<script src="<?php echo config_item('base_url').'/assets/' ?>js/adminlte.min.js"></script>

<!-- AdminLTE for demo purposes -->
<script src="<?php echo config_item('base_url').'/assets/' ?>js/demo.js"></script>

<!-- pace -->
<script src="<?php echo config_item('base_url').'/assets/' ?>plugins/pace/pace.min.js"></script>

<script>
  $('.content-wrapper').css({ 'min-height' : window.innerHeight-50, 'margin-left': 0 });
</script>

</body>
</html>
