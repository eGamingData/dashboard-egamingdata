<?php
defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<?php include viewPath('includes/header'); ?>

<!-- Content Header (Page header) -->
<section class="content-header">
  <h1>
    eGaming<span class="purple">Data</span> - Betting tracker
    <small>esports data for betting purpouses.</small>
  </h1>
  <span class="pull-right-container">
      
    </span>

</section>

<!-- Main content -->
<section class="content">
  <!-- Default box -->
  

</section>
<!-- /.content -->

<?php include viewPath('includes/footer'); ?>