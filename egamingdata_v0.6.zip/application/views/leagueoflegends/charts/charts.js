<script type="text/javascript">
    window.onload = function () {
        CanvasJS.addColorSet("greenShades",
                [//colorSet Array

                "#2F4F4F",
                "#008080",
                "#2E8B57",
                "#3CB371",
                "#90EE90"                
                ]);

      

        chart.render();
    }
  </script>