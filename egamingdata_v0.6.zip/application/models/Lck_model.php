<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lck_model extends MY_Model {

	public $table = 'lck';

	public function __construct()
	{
		parent::__construct();
	}

}

/* End of file Leagueoflegends_model.php */
/* Location: ./application/models/Leagueoflegends_model.php */