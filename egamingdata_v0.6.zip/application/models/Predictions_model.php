<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Predictions_model extends MY_Model {

	public $table = 'lol_models';

	public function __construct()
	{
		parent::__construct();
	}

}

/* End of file Leagueoflegends_model.php */
/* Location: ./application/models/Leagueoflegends_model.php */