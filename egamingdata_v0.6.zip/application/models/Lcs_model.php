<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lcs_model extends MY_Model {

	public $table = 'lcs';

	public function __construct()
	{
		parent::__construct();
	}

}

/* End of file Leagueoflegends_model.php */
/* Location: ./application/models/Leagueoflegends_model.php */